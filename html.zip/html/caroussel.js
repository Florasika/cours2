let slidePosition = 0;
const slides = document.getElementsByClassName('carousel-slide');
const totalSlides = slides.length;

document.getElementsByClassName("carousel-prev")[0].style.display = "none";

function nextSlide() {
  slides[slidePosition].classList.remove('active');
  slidePosition++;
  if (slidePosition === totalSlides) {
    slidePosition = 0;
  }
  slides[slidePosition].classList.add('active');

  if(slidePosition == 0){
      document.getElementsByClassName("carousel-prev")[0].style.display = "none";
  }else{
     document.getElementsByClassName("carousel-prev")[0].style.display = "block"; 
  }

  if(slidePosition == (totalSlides-1)){
      document.getElementsByClassName("carousel-next")[0].style.display = "none";
  }else{
     document.getElementsByClassName("carousel-next")[0].style.display = "block"; 
  }
}

function prevSlide() {
  slides[slidePosition].classList.remove('active');
  slidePosition--;
  if (slidePosition < 0) {
    slidePosition = totalSlides - 1;
  }
  slides[slidePosition].classList.add('active');

  if(slidePosition == 0){
      document.getElementsByClassName("carousel-prev")[0].style.display = "none";
  }else{
     document.getElementsByClassName("carousel-prev")[0].style.display = "block"; 
  }

  if(slidePosition == (totalSlides-1)){
      document.getElementsByClassName("carousel-next")[0].style.display = "none";
  }else{
     document.getElementsByClassName("carousel-next")[0].style.display = "block"; 
  }
}
