// Récupérer l'élément de l'image
var image = document.getElementById("image");

// Définir les propriétés initiales de l'animation
var x = 0; // position horizontale initiale
var y = 0; // position verticale initiale
var vx = 1; // vitesse horizontale
var vy = 1; // vitesse verticale

// Fonction d'animation
function animate() {
    // Mettre à jour la position de l'image
    x += vx;
    y += vy;
    image.style.left = x + "px";
    image.style.top = y + "px";

    // Vérifier si l'image atteint les bords de l'écran
    if (x + image.clientWidth >= window.innerWidth || x <= 0) {
        vx = -vx; // Inverser la direction horizontale
    }
    if (y + image.clientHeight >= window.innerHeight || y <= 0) {
        vy = -vy; // Inverser la direction verticale
    }

    // Appeler la fonction d'animation à chaque rafraîchissement de l'écran
    requestAnimationFrame(animate);
}

// Démarrer l'animation
animate();
