const form = document.querySelector('#message-form');
const input = form.querySelector('input');
const messages = document.querySelector('#messages');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const message = input.value;
  input.value = '';
  const li = document.createElement('li');
  li.textContent = message;
  messages.appendChild(li);
});
