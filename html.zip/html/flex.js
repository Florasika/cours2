const cards = document.querySelectorAll('.card');

cards.forEach(card => {
  const readMoreBtn = card.querySelector('.read-more');
  const content = card.querySelector('p');
  
  readMoreBtn.addEventListener('click', () => {
    content.classList.toggle('show');
    
    if (content.classList.contains('show')) {
      readMoreBtn.innerText = 'Read Less';
    } else {
      readMoreBtn.innerText = 'Read More';
    }
  });
});
